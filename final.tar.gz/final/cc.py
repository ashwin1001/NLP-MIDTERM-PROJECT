import networkx as nx
import pickle
import math

G=nx.Graph()
noun={}
verb={}
adjective={}


def create_graph():
    global G
    file=open('Graph/Full_DT_adj_list_proper_merged.txt','rb')
    G=nx.read_adjlist(file)

def read_data():
    global noun,verb,adjective

    file=open('nounlist.pkl','rb')
    noun=pickle.load(file)
    file.close()

    file1=open('verblist.pkl','rb')
    verb=pickle.load(file1)
    file1.close()

    file2=open('adjlist.pkl','rb')
    adjective=pickle.load(file2)

def nCr(n,r):
    f=math.factorial
    return f(n)/f(r)/f(n-r)

def induced_subgraph(noun1,attr):
    word1 = noun1.split('-')
    word2 = attr.split('-')
    word1[0].lower()
    word2[0].lower()
    if word2[1] == 'j':
        if (G.neighbors(noun[word1[0]]) is None) or (word2[0] not in adjective):
            return None
        
        if G.has_node(noun[word1[0]]) and G.has_node(adjective[word2[0]]):    
        	neighbours1 = set(G.neighbors(noun[word1[0]]))
        	neighbours2 = set(G.neighbors(adjective[word2[0]]))
        	neighbours = neighbours1.union(neighbours2)
        	graph= G.subgraph(list(neighbours))
        	return graph
        else:
        	return float(0.0)	
    if word2[1] == 'v':
        if (G.neighbors(noun[word1[0]]) is None) or (word2[0] not in verb):
            return None
        # print noun[word1[0]]
        if G.has_node(noun[word1[0]]) and G.has_node(verb[word2[0]]):    
        	neighbours1 = set(G.neighbors(noun[word1[0]]))
        	neighbours2 = set(G.neighbors(verb[word2[0]]))
       	 	neighbours = set(neighbours1).union(set(neighbours2))
        	graph= G.subgraph(list(neighbours))
        	return graph
        else:
        	return None

def cluster_coeff(noun1,attr):
        induced_subgraph1=induced_subgraph(noun1,attr)
        if induced_subgraph1 is not None:
            if induced_subgraph1.number_of_edges() is None:
                return float(0.0)
            else:
                return float(induced_subgraph1.number_of_edges())/nCr(len(induced_subgraph1),2)
        else:
            return float(0.0);
def entropy(noun1,attr):

    inducedgraph=induced_subgraph(noun1,attr)
    entropy=0.0
    for d in inducedgraph.nodes_iter(data=None):
        deg=inducedgraph.degree(d)
        if deg != 0:
            tot_nodes=len(inducedgraph)
            prob=float(deg)/tot_nodes

            entropy=entropy+(-prob*math.log(prob,2))
    return entropy
#def create_induced_graph():

def cosine_ss(noun1,attr):
    word1 = noun1.split('-')
    word2 = attr.split('-')
    if word2[1] == 'j':
        neighbours1 = set(G.neighbors(noun[word1[0]]))
        neighbours2 = set(G.neighbors(adjective[word2[0]]))
        coss=float(len(neighbours1.intersection(neighbours2)))/math.sqrt(len(neighbours1)*len(neighbours2))
        return coss
    if word2[1] == 'v':
        # print noun[word1[0]]
        neighbours1 = set(G.neighbors(noun[word1[0]]))
        neighbours2 = set(G.neighbors(verb[word2[0]]))
        coss = float(len(neighbours1.intersection(neighbours2))) / math.sqrt(len(neighbours1)*len(neighbours2))
        return coss

def euclidian_ss(noun1,attr):

    word1 = noun1.split('-')
    word2 = attr.split('-')
    if word2[1] == 'j':
        neighbours1 = set(G.neighbors(noun[word1[0]]))
        neighbours2 = set(G.neighbors(adjective[word2[0]]))
        coss=float(len(neighbours1.symmetric_difference(neighbours2)))/math.sqrt(len(neighbours1.union(neighbours2)))
        return coss
    if word2[1] == 'v':
        # print noun[word1[0]]
        neighbours1 = set(G.neighbors(noun[word1[0]]))
        neighbours2 = set(G.neighbors(verb[word2[0]]))
        coss = float(len(neighbours1.symmetric_difference(neighbours2))) / math.sqrt(len(neighbours1.union(neighbours2)))
        return coss

def avgpathlen(noun1,attr):
    sum=0.0
    inducedgraph=induced_subgraph(noun1,attr)
    V=inducedgraph.number_of_nodes()
    vts=inducedgraph.nodes()
    for i in vts:
        for j in vts:
            if i!=j:
                sum=sum+nx.shortest_path_length(G,i,j)
    return float(sum)/nCr(V,2)

def calculate_values():
    file = open('pairsnew.txt', 'r')
    file1=open('ccval.txt','w')
    file1.write('noun\tattr\tcluster_coeff\n')
    for line in file:
        str1=line.split()
        cc=cluster_coeff(str1[0],str1[1])
        #en=entropy(str1[0],str1[1])
        #cs=cosine_ss(str1[0],str1[1])
        #ess=euclidian_ss(str1[0],str1[1])
        #avg=avgpathlen(str1[0],str1[1])
        print cc
        file1.write(str1[0]+'\t'+str1[1]+'\t'+str(cc))
        #+'\t\t'+str(en)+'\t\t'+str(cs)+'\t\t'+str(ess)+'\t\t'+str(avg))
        #file1.write(str[0] + '\t' + str[1] + '\t' + str(cc) + '\t\t' + '%f' + '\t\t' + '%f' + '\t\t' + '%f' + '\t\t' + '%f') % (cc, en, cs, ess, avg)
        file1.write('\n')
    file1.close()
    file.close()

if __name__ == "__main__" :
    create_graph()
    read_data()
    print "graph created"
    #cc=cluster_coeff('ddd-n','do-v')
    #create_induced_graph()
    #print G.neighbors('11')
    #cc=entropy('ddd-n','do-v')
    #cc=cosine_ss('alli-n','small-j')
    #dd=euclidian_ss('alli-n','do-v')
    #cc=avgpathlen('alli-n','do-v')

    calculate_values()

